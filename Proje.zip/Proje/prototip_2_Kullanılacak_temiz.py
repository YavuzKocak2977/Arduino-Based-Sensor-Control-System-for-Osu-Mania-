import serial
import pyautogui
import time

SERIAL_PORT = 'COM7'
BAUD_RATE = 9600
TARGET_KEYS = ['d', 'f', 'j', 'k']
RECONNECT_DELAY = 5

arduino_serial = None
key_press_states = {key: False for key in TARGET_KEYS}

def connect_to_arduino_instance(port, baud_rate):
    global arduino_serial
    try:
        print(f"{port} portuna {baud_rate} baud rate ile bağlanılıyor...")
        ser = serial.Serial(port, baud_rate, timeout=1)
        time.sleep(2)
        if ser.is_open:
            print("Arduino ile bağlantı başarılı!")
            print(f"Sensörler ile '{', '.join(TARGET_KEYS)}' tuşları kontrol edilecek.")
            print("Arduino'dan beklenen sinyal formatı: [tuş_karakteri][D/U] (örn: dD, dU, fD, fU vb.)")
            print("Oyuna odaklanmak için bu pencereyi küçültebilirsin.")
            print("Programı sonlandırmak için CTRL+C yapın.")
            print("------------------------------------")
            arduino_serial = ser
            return True
        else:
            print("Bağlantı açılamadı (is_open false). Port meşgul olabilir veya Arduino yanıt vermiyor.")
            arduino_serial = None
            return False
    except serial.SerialException as e:
        print(f"Seri porta ({port}) bağlanılamadı.")
        print(f"Hata: {e}")
        print("Lütfen kontrol edin:")
        print("1. Arduino bilgisayara bağlı mı?")
        print(f"2. {port} doğru port mu? (Arduino IDE'den kontrol edin)")
        print("3. Arduino IDE'deki Seri Port Monitörü kapalı mı?")
        arduino_serial = None
        return False
    except Exception as e:
        print(f"Bağlantı sırasında beklenmedik bir hata oluştu: {e}")
        arduino_serial = None
        return False

def process_arduino_data(data_signal):
    global key_press_states

    if not data_signal or len(data_signal) != 2:
        return

    key_char = data_signal[0]
    action_char = data_signal[1]

    if key_char not in TARGET_KEYS:
        return

    if action_char == 'D':
        if not key_press_states[key_char]:
            pyautogui.keyDown(key_char)
            key_press_states[key_char] = True
            print(f"Sinyal '{data_signal}' -> '{key_char}' TUSUNA BASILDI")
    elif action_char == 'U':
        if key_press_states[key_char]:
            pyautogui.keyUp(key_char)
            key_press_states[key_char] = False
            print(f"Sinyal '{data_signal}' -> '{key_char}' TUSU BIRAKILDI")

def main_loop():
    global arduino_serial
    global key_press_states

    try:
        while True:
            if arduino_serial and arduino_serial.is_open:
                try:
                    if arduino_serial.in_waiting >= 2:
                        data_bytes = arduino_serial.read(2)
                        try:
                            data_str = data_bytes.decode('utf-8').strip()
                            process_arduino_data(data_str)
                        except UnicodeDecodeError:
                            pass
                    elif arduino_serial.in_waiting > 0:
                        _ = arduino_serial.read(arduino_serial.in_waiting)
                    else:
                        time.sleep(0.01)

                except serial.SerialException as e:
                    print(f"Seri port hatası (okuma/yazma sırasında): {e}. Bağlantı kesildi.")
                    if arduino_serial and arduino_serial.is_open:
                        arduino_serial.close()
                    arduino_serial = None
                    print(f"{RECONNECT_DELAY} saniye sonra yeniden bağlanılacak...")
                    time.sleep(RECONNECT_DELAY)
                except Exception as e:
                    print(f"Ana döngüde beklenmedik bir hata oluştu: {e}")
                    time.sleep(1)

            else:
                print("Arduino bağlantısı yok veya kapalı. Yeniden bağlanmaya çalışılıyor...")
                if not connect_to_arduino_instance(SERIAL_PORT, BAUD_RATE):
                    print(f"Yeniden bağlanma başarısız. {RECONNECT_DELAY} saniye sonra tekrar denenecek.")
                    time.sleep(RECONNECT_DELAY)

    except KeyboardInterrupt:
        print("\nProgram sonlandırılıyor (CTRL+C algılandı)...")
    finally:
        print("Program sonlandırma işlemleri yapılıyor...")
        if arduino_serial and arduino_serial.is_open:
            for key_char, is_pressed in key_press_states.items():
                if is_pressed:
                    pyautogui.keyUp(key_char)
                    print(f"Program kapatılırken '{key_char}' tuşu güvenlik amacıyla bırakıldı.")
                    key_press_states[key_char] = False
            arduino_serial.close()
            print("Seri port kapatıldı.")
        else:
            print("Seri port zaten kapalı veya hiç açılamamıştı.")
        print("Program sonlandı.")

if __name__ == "__main__":
    print("Python script'i başlatılıyor...")
    main_loop()